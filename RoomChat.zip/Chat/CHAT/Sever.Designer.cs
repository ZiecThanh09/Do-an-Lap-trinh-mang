﻿
namespace CHAT
{
    partial class Sever
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ListMess = new System.Windows.Forms.ListView();
            this.btnConnect = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // ListMess
            // 
            this.ListMess.HideSelection = false;
            this.ListMess.Location = new System.Drawing.Point(34, 29);
            this.ListMess.Name = "ListMess";
            this.ListMess.Size = new System.Drawing.Size(475, 246);
            this.ListMess.TabIndex = 0;
            this.ListMess.UseCompatibleStateImageBehavior = false;
            this.ListMess.View = System.Windows.Forms.View.List;
            // 
            // btnConnect
            // 
            this.btnConnect.Location = new System.Drawing.Point(590, 80);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(124, 66);
            this.btnConnect.TabIndex = 1;
            this.btnConnect.Text = "Connect";
            this.btnConnect.UseVisualStyleBackColor = true;
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);
            // 
            // Sever
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnConnect);
            this.Controls.Add(this.ListMess);
            this.Name = "Sever";
            this.Text = "`";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListView ListMess;
        private System.Windows.Forms.Button btnConnect;
    }
}