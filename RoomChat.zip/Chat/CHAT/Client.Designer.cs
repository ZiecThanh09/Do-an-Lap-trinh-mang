﻿
namespace Chat
{
    partial class Client
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnClickChat = new System.Windows.Forms.Button();
            this.btnAnBoxChat = new System.Windows.Forms.Button();
            this.ListMess = new System.Windows.Forms.ListView();
            this.tbMess = new System.Windows.Forms.TextBox();
            this.btnSend = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.tbUserName = new System.Windows.Forms.TextBox();
            this.btnOut = new System.Windows.Forms.Button();
            this.tbGoiY1 = new System.Windows.Forms.TextBox();
            this.tbGoiY3 = new System.Windows.Forms.TextBox();
            this.tbGoiY2 = new System.Windows.Forms.TextBox();
            this.tbGoiY4 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnClickChat
            // 
            this.btnClickChat.BackColor = System.Drawing.Color.White;
            this.btnClickChat.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnClickChat.Location = new System.Drawing.Point(293, 58);
            this.btnClickChat.Margin = new System.Windows.Forms.Padding(4);
            this.btnClickChat.Name = "btnClickChat";
            this.btnClickChat.Size = new System.Drawing.Size(145, 59);
            this.btnClickChat.TabIndex = 4;
            this.btnClickChat.Text = "Click để chat";
            this.btnClickChat.UseVisualStyleBackColor = false;
            this.btnClickChat.Click += new System.EventHandler(this.btnClickChat_Click);
            // 
            // btnAnBoxChat
            // 
            this.btnAnBoxChat.BackColor = System.Drawing.Color.White;
            this.btnAnBoxChat.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnAnBoxChat.Location = new System.Drawing.Point(526, 13);
            this.btnAnBoxChat.Margin = new System.Windows.Forms.Padding(4);
            this.btnAnBoxChat.Name = "btnAnBoxChat";
            this.btnAnBoxChat.Size = new System.Drawing.Size(145, 59);
            this.btnAnBoxChat.TabIndex = 5;
            this.btnAnBoxChat.Text = "Ẩn box chat";
            this.btnAnBoxChat.UseVisualStyleBackColor = false;
            this.btnAnBoxChat.Click += new System.EventHandler(this.btnAnBoxChat_Click);
            // 
            // ListMess
            // 
            this.ListMess.HideSelection = false;
            this.ListMess.Location = new System.Drawing.Point(46, 172);
            this.ListMess.Name = "ListMess";
            this.ListMess.Size = new System.Drawing.Size(625, 330);
            this.ListMess.TabIndex = 6;
            this.ListMess.UseCompatibleStateImageBehavior = false;
            this.ListMess.View = System.Windows.Forms.View.List;
            // 
            // tbMess
            // 
            this.tbMess.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.tbMess.Location = new System.Drawing.Point(46, 615);
            this.tbMess.Name = "tbMess";
            this.tbMess.Size = new System.Drawing.Size(511, 34);
            this.tbMess.TabIndex = 7;
            // 
            // btnSend
            // 
            this.btnSend.BackColor = System.Drawing.Color.White;
            this.btnSend.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnSend.Location = new System.Drawing.Point(582, 615);
            this.btnSend.Margin = new System.Windows.Forms.Padding(4);
            this.btnSend.Name = "btnSend";
            this.btnSend.Size = new System.Drawing.Size(89, 34);
            this.btnSend.TabIndex = 8;
            this.btnSend.Text = "Gửi";
            this.btnSend.UseVisualStyleBackColor = false;
            this.btnSend.Click += new System.EventHandler(this.btnSend_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(41, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(164, 25);
            this.label1.TabIndex = 9;
            this.label1.Text = "Nhập username";
            // 
            // tbUserName
            // 
            this.tbUserName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.tbUserName.Location = new System.Drawing.Point(46, 90);
            this.tbUserName.Name = "tbUserName";
            this.tbUserName.Size = new System.Drawing.Size(218, 27);
            this.tbUserName.TabIndex = 10;
            // 
            // btnOut
            // 
            this.btnOut.BackColor = System.Drawing.Color.White;
            this.btnOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnOut.Location = new System.Drawing.Point(526, 90);
            this.btnOut.Margin = new System.Windows.Forms.Padding(4);
            this.btnOut.Name = "btnOut";
            this.btnOut.Size = new System.Drawing.Size(145, 59);
            this.btnOut.TabIndex = 11;
            this.btnOut.Text = "Thoát phòng";
            this.btnOut.UseVisualStyleBackColor = false;
            this.btnOut.Click += new System.EventHandler(this.btnOut_Click);
            // 
            // tbGoiY1
            // 
            this.tbGoiY1.BackColor = System.Drawing.Color.White;
            this.tbGoiY1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbGoiY1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F);
            this.tbGoiY1.Location = new System.Drawing.Point(46, 527);
            this.tbGoiY1.Name = "tbGoiY1";
            this.tbGoiY1.ReadOnly = true;
            this.tbGoiY1.Size = new System.Drawing.Size(310, 27);
            this.tbGoiY1.TabIndex = 12;
            this.tbGoiY1.Text = "Hello, cùng chơi thôi nào";
            this.tbGoiY1.Click += new System.EventHandler(this.tbGoiY1_Click);
            // 
            // tbGoiY3
            // 
            this.tbGoiY3.BackColor = System.Drawing.Color.White;
            this.tbGoiY3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbGoiY3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F);
            this.tbGoiY3.Location = new System.Drawing.Point(46, 575);
            this.tbGoiY3.Name = "tbGoiY3";
            this.tbGoiY3.Size = new System.Drawing.Size(218, 27);
            this.tbGoiY3.TabIndex = 13;
            this.tbGoiY3.Text = "Úi xời non";
            this.tbGoiY3.Click += new System.EventHandler(this.tbGoiY3_Click);
            // 
            // tbGoiY2
            // 
            this.tbGoiY2.BackColor = System.Drawing.Color.White;
            this.tbGoiY2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbGoiY2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F);
            this.tbGoiY2.Location = new System.Drawing.Point(401, 527);
            this.tbGoiY2.Name = "tbGoiY2";
            this.tbGoiY2.Size = new System.Drawing.Size(270, 27);
            this.tbGoiY2.TabIndex = 14;
            this.tbGoiY2.Text = "Hihiiiiii, out trình";
            this.tbGoiY2.Click += new System.EventHandler(this.tbGoiY2_Click);
            // 
            // tbGoiY4
            // 
            this.tbGoiY4.BackColor = System.Drawing.Color.White;
            this.tbGoiY4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbGoiY4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F);
            this.tbGoiY4.Location = new System.Drawing.Point(314, 574);
            this.tbGoiY4.Name = "tbGoiY4";
            this.tbGoiY4.Size = new System.Drawing.Size(357, 27);
            this.tbGoiY4.TabIndex = 15;
            this.tbGoiY4.Text = "Thôi bye nha, mình bận rồi";
            this.tbGoiY4.Click += new System.EventHandler(this.tbGoiY4_Click);
            // 
            // Client
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(739, 671);
            this.Controls.Add(this.tbGoiY4);
            this.Controls.Add(this.tbGoiY2);
            this.Controls.Add(this.tbGoiY3);
            this.Controls.Add(this.tbGoiY1);
            this.Controls.Add(this.btnOut);
            this.Controls.Add(this.tbUserName);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnSend);
            this.Controls.Add(this.tbMess);
            this.Controls.Add(this.ListMess);
            this.Controls.Add(this.btnAnBoxChat);
            this.Controls.Add(this.btnClickChat);
            this.Name = "Client";
            this.Text = "Client";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Client_FormClosed);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnClickChat;
        private System.Windows.Forms.Button btnAnBoxChat;
        private System.Windows.Forms.ListView ListMess;
        private System.Windows.Forms.TextBox tbMess;
        private System.Windows.Forms.Button btnSend;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbUserName;
        private System.Windows.Forms.Button btnOut;
        private System.Windows.Forms.TextBox tbGoiY1;
        private System.Windows.Forms.TextBox tbGoiY3;
        private System.Windows.Forms.TextBox tbGoiY2;
        private System.Windows.Forms.TextBox tbGoiY4;
    }
}