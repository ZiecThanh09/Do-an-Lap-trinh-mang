﻿
namespace Chat
{
    partial class ShowBoxChat
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnBoxChat = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnBoxChat
            // 
            this.btnBoxChat.BackColor = System.Drawing.Color.White;
            this.btnBoxChat.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnBoxChat.Location = new System.Drawing.Point(-1, -1);
            this.btnBoxChat.Margin = new System.Windows.Forms.Padding(4);
            this.btnBoxChat.Name = "btnBoxChat";
            this.btnBoxChat.Size = new System.Drawing.Size(212, 60);
            this.btnBoxChat.TabIndex = 5;
            this.btnBoxChat.Text = "Box Chat";
            this.btnBoxChat.UseVisualStyleBackColor = false;
            this.btnBoxChat.Click += new System.EventHandler(this.btnBoxChat_Click);
            // 
            // ShowBoxChat
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(211, 59);
            this.ControlBox = false;
            this.Controls.Add(this.btnBoxChat);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.IsMdiContainer = true;
            this.Name = "ShowBoxChat";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnBoxChat;
    }
}