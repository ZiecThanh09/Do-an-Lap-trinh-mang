﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.IO;

namespace CHAT
{
    public partial class Player : Form
    {
        IPEndPoint IP;
        TcpClient Client;
        StreamReader Reader;
        StreamWriter Writer;
        bool Stop = true;
        public Player()
        {
            InitializeComponent();
            UpdateTextPosition();
        }
        private void UpdateTextPosition()
        {
            Graphics g = this.CreateGraphics();
            Double startingPoint = (this.Width / 2) - (g.MeasureString(this.Text.Trim(), this.Font).Width / 2);
            Double widthOfASpace = g.MeasureString(" ", this.Font).Width;
            String tmp = " ";
            Double tmpWidth = 0;

            while ((tmpWidth + widthOfASpace) < startingPoint)
            {
                tmp += " ";
                tmpWidth += widthOfASpace;
            }

            this.Text = tmp + this.Text.Trim();
        }

        ShowBoxChat ShowBox;
        public Player(ShowBoxChat Form)
        {
            InitializeComponent();
            UpdateTextPosition();
            ShowBox = Form;
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            if (!tbMess.Text.Equals(String.Empty) && Client.Connected)
            {
                byte[] DATA = Encoding.UTF8.GetBytes(tbMess.Text + '\0');
                Writer.BaseStream.Write(DATA, 0, DATA.Length);
                tbMess.Clear();
            }
        }

        private void btnHienBoxChat_Click(object sender, EventArgs e)
        {
            CheckForIllegalCrossThreadCalls = false;
            string ip = "127.0.0.1";
            try
            {
                IP = new IPEndPoint(IPAddress.Parse(ip), 8080);
                Client = new TcpClient();
                try
                {
                    Console.WriteLine(IP.ToString());
                    Client.Connect(IP);
                    Stop = false;
                    Reader = new StreamReader(Client.GetStream());
                    Writer = new StreamWriter(Client.GetStream());
                    Thread ClientThread = new Thread(Recv);
                    ClientThread.IsBackground = true;
                    ClientThread.Start();
                }
                catch
                {
                    Client.Dispose();
                    Client = null;
                    return;
                }
            }
            catch
            {
                Client.Dispose();
                Client = null;
                return;
            }
        }
        void Recv()
        {
            try
            {
                while (Stop == false)
                {
                    byte[] data = new byte[1024];
                    Reader.BaseStream.Read(data, 0, data.Length);

                    string s = Encoding.UTF8.GetString(data);
                    Console.WriteLine(s);
                    if (s.Contains("@CloseRoom.Sever"))
                    {
                        CLOSE();
                        return;
                    }
                    if (s != "")
                        ListMess.Items.Add(new ListViewItem(s));
                }
            }
            catch
            {
                CLOSE();
            }
        }
        void CLOSE()
        {
            if (Client != null)
            {
                try
                {
                    byte[] s = Encoding.UTF8.GetBytes("@CloseRoom.Client");
                    Writer.BaseStream.Write(s, 0, s.Length);
                    Client.Close();
                    Client = null;
                }
                catch {}
            }
            Stop = true;
        }

        private void btnAnBoxChat_Click(object sender, EventArgs e)
        {
            ShowBox.ShowBox(this);
            ShowBox.Show();
            this.Hide();
        }
    }
}
