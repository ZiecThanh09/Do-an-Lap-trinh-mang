﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace CHAT
{
    public partial class Sever : Form
    {
        public Sever()
        {
            InitializeComponent();
        }
        TcpListener Server;
        IPEndPoint IP;
        Dictionary<string, TcpClient> ListPlayer = new Dictionary<string, TcpClient>();
        bool Stop = false;


        void Connect()
        {
            if (Server != null)
                CLOSE();
            IP = new IPEndPoint(IPAddress.Any, 8080);
            Server = new TcpListener(IP);
            Server.Start();
            Stop = false;
            Thread Listen = new Thread(() =>
            {
                try
                {
                    ListPlayer = new Dictionary<string, TcpClient>();
                    while (Stop == false)
                    {
                        if (Server.Pending() == true)
                        {
                            TcpClient Client = Server.AcceptTcpClient();
                            if (Client != null)
                            {
                                if (ListPlayer.Values.Contains(Client) == false)
                                {
                                    while (Client.Available == 0) { };
                                    byte[] t = new byte[1024 * 1000];
                                    Client.GetStream().Read(t, 0, t.Length);
                                    string st = Encoding.UTF8.GetString(t).Split(':')[1].Split('.')[0];
                                    string MSG = st + " logged in from" + Client.Client.RemoteEndPoint.ToString();
                                    ListPlayer.Add(st, Client);
                                    foreach (TcpClient ClientX in ListPlayer.Values)
                                    {
                                        Send(ClientX, MSG);
                                    }
                                    ListMess.Items.Add(new ListViewItem(MSG));
                                    Console.WriteLine(MSG);
                                }
                                Thread SeverThread = new Thread(Receive);
                                SeverThread.IsBackground = true;
                                SeverThread.Start(Client);
                            }

                        }
                    }

                }
                catch
                {
                    ListPlayer.Clear();
                    Close();
                    return;
                }
            });
            Listen.IsBackground = true;
            Listen.Start();
        }
        void Receive(object obj)
        {
            TcpClient client = obj as TcpClient;
            NetworkStream ns = client.GetStream();
            try
            {
                while (Stop == false)
                {
                    byte[] data = new byte[1024];
                    ns.Read(data, 0, data.Length);
                    string str = System.Text.Encoding.UTF8.GetString(data);
                    str = str.Split('\0')[0];
                    if (str.Contains("close.from.client"))
                    {
                        ListMess.Items.Add(new ListViewItem(str.Split(':')[1] + " logged out"));
                        foreach (TcpClient item in ListPlayer.Values)
                        {
                            Send(item, str.Split(':')[1] + " logged out\0");

                        }
                        foreach (KeyValuePair<string, TcpClient> item in ListPlayer)
                        {
                            if (item.Value == client)
                            {
                                ListPlayer.Remove(item.Key);
                                break;
                            }

                        }

                    }
                    else
                    {
                        string temp = "";
                        foreach (KeyValuePair<string, TcpClient> c in ListPlayer)
                        {
                            if (c.Value == client)
                            {
                                ListMess.Items.Add(new ListViewItem(c.Key + ": " + str));
                                temp = c.Key;
                            }


                        }
                        foreach (KeyValuePair<string, TcpClient> c in ListPlayer)
                        {
                            Send(c.Value, temp + ": " + str + '\0');
                        }


                    }

                    str = "";
                }
                client.Close();
            }
            catch
            {
                foreach (KeyValuePair<string, TcpClient> item in ListPlayer)
                {
                    if (item.Value == client)
                    {
                        ListPlayer.Remove(item.Key);
                        break;
                    }
                }

                client.Close();
            }
        }
        void Send(TcpClient client, string str)
        {
            if (client != null && str != String.Empty)
            {
                NetworkStream ns = client.GetStream();
                byte[] data = System.Text.Encoding.UTF8.GetBytes(str);
                ns.Write(data, 0, data.Length);
            }
        }
        void CLOSE()
        {
            foreach (TcpClient c in ListPlayer.Values)
            {
                Send(c, "close.haha.fromServer");
            }

            if (Server != null)
            {
                Server.Stop();
            }
            Server = null;
            Stop = true;
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            Connect();
        }
    }
}
