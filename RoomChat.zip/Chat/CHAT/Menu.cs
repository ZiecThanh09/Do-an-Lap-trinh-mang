﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Chat
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }

        private void btnClient_Click(object sender, EventArgs e)
        {
            Client Form = new Client();
            Form.Show();
        }

        private void btnSever_Click(object sender, EventArgs e)
        {
            Server Form = new Server();
            Form.Show();
            btnSever.Enabled = false;
        }
    }
}
