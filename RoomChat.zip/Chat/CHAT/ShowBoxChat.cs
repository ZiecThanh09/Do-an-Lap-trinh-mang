﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Chat
{
    public partial class ShowBoxChat : Form
    {
        public ShowBoxChat()
        {
            InitializeComponent();
        }
        Client cl;
        public ShowBoxChat(Client get)
        {
            InitializeComponent();
            cl = get;
        }

        //private Form KiemTraTonTai(Type formType)
        //{
        //    foreach (Form f in this.MdiChildren)
        //    {
        //        if (f.GetType() == formType)
        //            return f;
        //    }
        //    return null;
        //}

        private void btnBoxChat_Click(object sender, EventArgs e)
        {
            //Form frm = KiemTraTonTai(typeof(Client));
            //if (frm != null)
            //    frm.Activate();
            //else
            //{
            //    Client f = new Client();
            //    f.showform = this;
            //    f.MdiParent = this.MdiParent;
            //    this.Visible = false;
            //    f.Visible = true;
            //}
            this.Hide();
            cl.Show();
        }
    }
}
