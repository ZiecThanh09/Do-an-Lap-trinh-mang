﻿
namespace CHAT
{
    partial class Player
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ListMess = new System.Windows.Forms.ListView();
            this.tbMess = new System.Windows.Forms.TextBox();
            this.btnSend = new System.Windows.Forms.Button();
            this.btnClickChat = new System.Windows.Forms.Button();
            this.btnAnBoxChat = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // ListMess
            // 
            this.ListMess.HideSelection = false;
            this.ListMess.Location = new System.Drawing.Point(12, 92);
            this.ListMess.Name = "ListMess";
            this.ListMess.Size = new System.Drawing.Size(453, 330);
            this.ListMess.TabIndex = 0;
            this.ListMess.UseCompatibleStateImageBehavior = false;
            this.ListMess.View = System.Windows.Forms.View.List;
            // 
            // tbMess
            // 
            this.tbMess.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.tbMess.Location = new System.Drawing.Point(12, 441);
            this.tbMess.Name = "tbMess";
            this.tbMess.Size = new System.Drawing.Size(322, 34);
            this.tbMess.TabIndex = 1;
            // 
            // btnSend
            // 
            this.btnSend.BackColor = System.Drawing.Color.White;
            this.btnSend.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnSend.Location = new System.Drawing.Point(376, 441);
            this.btnSend.Margin = new System.Windows.Forms.Padding(4);
            this.btnSend.Name = "btnSend";
            this.btnSend.Size = new System.Drawing.Size(89, 34);
            this.btnSend.TabIndex = 2;
            this.btnSend.Text = "Send";
            this.btnSend.UseVisualStyleBackColor = false;
            this.btnSend.Click += new System.EventHandler(this.btnSend_Click);
            // 
            // btnClickChat
            // 
            this.btnClickChat.BackColor = System.Drawing.Color.White;
            this.btnClickChat.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnClickChat.Location = new System.Drawing.Point(12, 13);
            this.btnClickChat.Margin = new System.Windows.Forms.Padding(4);
            this.btnClickChat.Name = "btnClickChat";
            this.btnClickChat.Size = new System.Drawing.Size(145, 59);
            this.btnClickChat.TabIndex = 3;
            this.btnClickChat.Text = "Click để chat";
            this.btnClickChat.UseVisualStyleBackColor = false;
            this.btnClickChat.Click += new System.EventHandler(this.btnHienBoxChat_Click);
            // 
            // btnAnBoxChat
            // 
            this.btnAnBoxChat.BackColor = System.Drawing.Color.White;
            this.btnAnBoxChat.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnAnBoxChat.Location = new System.Drawing.Point(320, 13);
            this.btnAnBoxChat.Margin = new System.Windows.Forms.Padding(4);
            this.btnAnBoxChat.Name = "btnAnBoxChat";
            this.btnAnBoxChat.Size = new System.Drawing.Size(145, 59);
            this.btnAnBoxChat.TabIndex = 4;
            this.btnAnBoxChat.Text = "Ẩn box chat";
            this.btnAnBoxChat.UseVisualStyleBackColor = false;
            this.btnAnBoxChat.Click += new System.EventHandler(this.btnAnBoxChat_Click);
            // 
            // Player
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(525, 532);
            this.ControlBox = false;
            this.Controls.Add(this.btnAnBoxChat);
            this.Controls.Add(this.btnClickChat);
            this.Controls.Add(this.btnSend);
            this.Controls.Add(this.tbMess);
            this.Controls.Add(this.ListMess);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Player";
            this.Text = "BOX CHAT";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView ListMess;
        private System.Windows.Forms.TextBox tbMess;
        private System.Windows.Forms.Button btnSend;
        private System.Windows.Forms.Button btnClickChat;
        private System.Windows.Forms.Button btnAnBoxChat;
    }
}

