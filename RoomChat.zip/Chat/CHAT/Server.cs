﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.IO;

namespace Chat
{
    public partial class Server : Form
    {
        TcpListener SVR;
        IPEndPoint IP;
        Dictionary<string, TcpClient> clientList = new Dictionary<string, TcpClient>();
        bool Stop = false;
        public Server()
        {
            InitializeComponent();
        }

        private void btnListen_Click(object sender, EventArgs e)
        {
            CheckForIllegalCrossThreadCalls = false;
            if (SVR != null) 
                Close();
            try
            {
                IP = new IPEndPoint(IPAddress.Any, 8080);
            }
            catch
            {
                return;
            }
            SVR = new TcpListener(IP);
            SVR.Start();
            Stop = false;
            Thread Listen = new Thread(() =>
            {

                try
                {
                    clientList = new Dictionary<string, TcpClient>();
                    while (Stop == false)
                    {
                        if (SVR.Pending() == true)
                        {
                            TcpClient client = SVR.AcceptTcpClient();
                            if (client != null)
                            {
                                if (clientList.Values.Contains(client) == false)
                                {
                                    while (client.Available == 0) { };
                                    byte[] temp = new byte[1024 * 1000];
                                    client.GetStream().Read(temp, 0, temp.Length);
                                    string st = Encoding.UTF8.GetString(temp).Split(':')[1].Split('.')[0];
                                    string mess = st + " đã tham gia vào phòng";
                                    clientList.Add(st, client);
                                    foreach (TcpClient item in clientList.Values)
                                    {
                                        Send(item, mess);
                                    }
                                    List.Items.Add(new ListViewItem(mess));
                                    Console.WriteLine(mess);
                                }
                                Thread receive = new Thread(Receive);
                                receive.IsBackground = true;
                                receive.Start(client);
                            }

                        }
                    }

                }
                catch
                {
                    clientList.Clear();
                    Close();
                    return;
                }
            });
            Listen.IsBackground = true;
            Listen.Start();
            btnListen.Enabled = false;
        }
        void Close()
        {
            foreach (TcpClient c in clientList.Values)
            {
                Send(c, "close.Server");
            }

            if (SVR != null)
            {
                SVR.Stop();
            }
            SVR = null;
            Stop = true;

        }
        void Send(TcpClient client, string str)
        {
            if (client != null && str != String.Empty)
            {
                NetworkStream ns = client.GetStream();
                byte[] data = System.Text.Encoding.UTF8.GetBytes(str);
                ns.Write(data, 0, data.Length);
            }
        }
        void Receive(object obj)
        {
            TcpClient client = obj as TcpClient;
            NetworkStream ns = client.GetStream();
            try
            {
                while (Stop == false)
                {
                    byte[] data = new byte[1024];
                    ns.Read(data, 0, data.Length);
                    string str = Encoding.UTF8.GetString(data);
                    str = str.Split('\0')[0];
                    if (str.Contains("close.client"))
                    {
                        AddMessage(str.Split(':')[1] + " đã rời khỏi phòng");
                        foreach (TcpClient item in clientList.Values)
                        {
                            Send(item, str.Split(':')[1] + " đã rời khỏi phòng\0");
                        }
                        foreach (KeyValuePair<string, TcpClient> item in clientList)
                        {
                            if (item.Value == client)
                            {
                                clientList.Remove(item.Key);
                                break;
                            }
                        }

                    }
                    else
                    {
                        string temp = "";
                        foreach (KeyValuePair<string, TcpClient> c in clientList)
                        {
                            if (c.Value == client)
                            {
                                AddMessage(c.Key + ": " + str);
                                temp = c.Key;
                            }
                        }
                        foreach (KeyValuePair<string, TcpClient> c in clientList)
                        {
                            Send(c.Value, temp + ": " + str + '\0');
                        }
                    }
                    str = "";
                }
                client.Close();
            }
            catch
            {
                foreach (KeyValuePair<string, TcpClient> item in clientList)
                {
                    if (item.Value == client)
                    {
                        clientList.Remove(item.Key);
                        break;
                    }
                }

                client.Close();
            }
        }
        void AddMessage(string s)
        {
            List.Items.Add(new ListViewItem() { Text = s });
        }
    }
}
