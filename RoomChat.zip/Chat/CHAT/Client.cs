﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.IO;

namespace Chat
{
    public partial class Client : Form
    {
        IPEndPoint IP;
        TcpClient client;
        StreamReader r;
        StreamWriter w;
        bool closed = true;

        public Client()
        {
            InitializeComponent();
        }
        private void btnClickChat_Click(object sender, EventArgs e)
        {
            CheckForIllegalCrossThreadCalls = false;
            string ip = "127.0.0.1";
            if (client != null)
            {
                Close();
                client = null;
            }
            try
            {
                IP = new IPEndPoint(IPAddress.Parse(ip), 8080);
                client = new TcpClient();
                try
                {
                    Console.WriteLine(IP.ToString());
                    client.Connect(IP);
                    closed = false;
                    btnClickChat.Enabled = false;
                    r = new StreamReader(client.GetStream());
                    w = new StreamWriter(client.GetStream());
                    byte[] un = Encoding.UTF8.GetBytes("username.from.client:" + tbUserName.Text + ".");
                    w.BaseStream.Write(un, 0, un.Length);
                    Thread Listen = new Thread(Receive);
                    Listen.IsBackground = true;
                    Listen.Start();
                }
                catch
                {
                    client.Dispose();
                    client = null;
                    return;
                }
            }
            catch
            {
                client.Dispose();
                client = null;
                return;
            }
        }
        void Close()
        {

            if (client != null)
            {
                try
                {
                    AddMessage(tbUserName.Text + " đã rời khỏi phòng");
                    byte[] cl = Encoding.UTF8.GetBytes("close.client:" + tbUserName.Text);
                    w.BaseStream.Write(cl, 0, cl.Length);
                    client.Close();
                    client = null;
                }
                catch
                {}
            }
            btnClickChat.Enabled = true;
            closed = true;
        }
        void Receive()
        {
            try
            {

                while (closed == false)
                {
                    byte[] data = new byte[512];
                    r.BaseStream.Read(data, 0, data.Length);
                    string str = Encoding.UTF8.GetString(data);
                    Console.WriteLine(str);
                    if (str.Contains("close.Server"))
                    {
                        Close();
                        MessageBox.Show("Disconnected");
                        return;
                    }
                    if (str.Equals(String.Empty) == false) AddMessage(str);
                }
            }
            catch
            {
                Close();
            }
        }
        void AddMessage(string str)
        {
            ListMess.Items.Add(new ListViewItem() { Text = str });
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            if (!tbMess.Text.Equals(String.Empty) && client.Connected)
            {
                byte[] data = Encoding.UTF8.GetBytes(tbMess.Text + '\0');
                w.BaseStream.Write(data, 0, data.Length);
                tbMess.Clear();
            }
        }
        private void btnAnBoxChat_Click(object sender, EventArgs e)
        {
            this.Hide();
            ShowBoxChat show = new ShowBoxChat(this);
            show.Show();
        }

        private void btnOut_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Client_FormClosed(object sender, FormClosedEventArgs e)
        {
            Close();
        }

        string a1 = "Sợ chưa, sợ chưa???";
        string a2 = "Không có tuổiiiiii";
        string a3 = "Hmmm, cũng khá đấy";
        string a4 = "GG thôi nàooooooo";
        string a5 = "Ái chà chà, kinh thế";
        string a6 = "Đánh lẹ lên má";
        string a7 = "Kinh thế nhờ";
        string a8 = "Ok, bạn là nhất";
        string a9 = "Không phục, chơi lại ván nữa đi";
        string a10 = "Trời đất ơi, đánh gì hay quá vậyyy";
        private string Randomchuoi(int i)
        {
            switch (i)
            {
                case 1:
                    return a1;
                case 2:
                    return a2;
                case 3:
                    return a3;
                case 4:
                    return a4;
                case 5:
                    return a5;
                case 6:
                    return a6;
                case 7:
                    return a7;
                case 8:
                    return a8;
                case 9:
                    return a9;
                case 10:
                    return a10;
            }
            return "";
        }
            
        private void tbGoiY1_Click(object sender, EventArgs e)
        {
            tbMess.Text = tbGoiY1.Text;
            Random ran = new Random();
            int i = ran.Next(1, 10);
            tbGoiY1.Text = Randomchuoi(i);
        }

        private void tbGoiY2_Click(object sender, EventArgs e)
        {
            tbMess.Text = tbGoiY2.Text;
            Random ran = new Random();
            int i = ran.Next(1, 10);
            tbGoiY2.Text = Randomchuoi(i);
        }

        private void tbGoiY3_Click(object sender, EventArgs e)
        {
            tbMess.Text = tbGoiY3.Text;
            Random ran = new Random();
            int i = ran.Next(1, 10);
            tbGoiY3.Text = Randomchuoi(i);
        }

        private void tbGoiY4_Click(object sender, EventArgs e)
        {
            tbMess.Text = tbGoiY4.Text;
            Random ran = new Random();
            int i = ran.Next(1, 10);
            tbGoiY4.Text = Randomchuoi(i);
        }
    }
}
